<?php

namespace Picqer\Barcode\Exceptions;

class UnknownTypeException extends BarcodeException {}